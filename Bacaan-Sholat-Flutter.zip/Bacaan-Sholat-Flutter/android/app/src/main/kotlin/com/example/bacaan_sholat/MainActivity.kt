package com.example.bacaan_sholat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
